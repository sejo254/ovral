const backgrounds = [
    'background1.jpg',
    'background2.jpg',
    'background3.jpg'
  ];
  
  let currentBackgroundIndex = 0;
  
  document.getElementById('nextButton').addEventListener('click', () => {
    if (currentBackgroundIndex === backgrounds.length - 1) {
      currentBackgroundIndex = 0;
    } else {
      currentBackgroundIndex++;
    }
    const nextPageUrl = `page${currentBackgroundIndex + 1}.html`;
    window.location.href = nextPageUrl;
  });
  